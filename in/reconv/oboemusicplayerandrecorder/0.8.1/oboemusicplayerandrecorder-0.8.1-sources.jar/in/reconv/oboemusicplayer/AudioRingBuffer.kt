package `in`.reconv.oboemusicplayer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import android.util.Log

class AudioRingBuffer(capacityInBytes: Int) {
    private val buffer = ByteBuffer.allocateDirect(capacityInBytes).order(ByteOrder.nativeOrder())
    private var writePos = 0
    private var readPos = 0
    private var size = 0
    private val capacity = capacityInBytes

    private val lock = ReentrantLock()
    private val dataAvailable = lock.newCondition()

    fun write(data: ByteBuffer) {
        lock.withLock {
            val dataSize = data.remaining()
            data.clear()  // Reset position to start

            // Write data to ring buffer
            for (i in 0 until dataSize) {
                buffer.put(writePos, data.get())
                writePos = (writePos + 1) % capacity

                if (size < capacity) {
                    size++
                } else {
                    // Overwrite scenario: advance read pointer
                    readPos = (readPos + 1) % capacity
                }
            }

//            Log.d("AudioRingBuffer", "Written $dataSize bytes, size=$size")
            dataAvailable.signalAll()
        }
    }

    fun read(output: ByteBuffer, length: Int): Boolean {
        lock.withLock {
            // Check if we have enough data
            if (size < length) {
//                Log.d("AudioRingBuffer", "Not enough data: have $size, need $length")
                return false
            }

            output.clear()
            // Read requested amount of data
            for (i in 0 until length) {
                output.put(buffer.get(readPos))
                readPos = (readPos + 1) % capacity
                size--
            }

            output.flip()  // Prepare for reading
//            Log.d("AudioRingBuffer", "Read $length bytes, remaining=$size")
            return true
        }
    }

    fun available(): Int = lock.withLock { size }

    fun clear() {
        lock.withLock {
            writePos = 0
            readPos = 0
            size = 0
            buffer.clear()
        }
    }
}