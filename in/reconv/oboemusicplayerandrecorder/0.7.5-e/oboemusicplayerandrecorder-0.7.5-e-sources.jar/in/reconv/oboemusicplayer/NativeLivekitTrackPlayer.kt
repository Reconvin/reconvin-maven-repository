package `in`.reconv.oboemusicplayer

class NativeLivekitTrackPlayer {

    external fun createPlayer(): Boolean

    companion object{
        init {
            System.loadLibrary("OboeMusicPlayerAndRecorder")
        }
    }

    fun setupAudioStream(){
        setupAudioStreamNative()
    }

    fun startAudioStream() {
        startAudioStreamNative()
    }

    fun teardownAudioStream() {
        teardownAudioStreamNative()
    }

    /**
     * Pause the audio stream - keeps the stream alive but outputs silence.
     * Also clears FIFO buffers so old audio data won't mix with new data.
     * Use this instead of teardownAudioStream() between playback sessions.
     */
    fun pauseStream() {
        pauseStreamNative()
    }

    /**
     * Resume the audio stream after pause.
     * Clears any stale buffer data before resuming so you get clean audio.
     * Call this when starting a new playback session.
     */
    fun resumeStream() {
        resumeStreamNative()
    }

    /**
     * Clear all FIFO buffers to remove any stale/old audio data.
     * Useful before writing new audio data to ensure clean output.
     */
    fun clearBuffers() {
        clearBuffersNative()
    }

    /**
     * Check if the audio stream is currently active and running.
     */
    fun isStreamActive(): Boolean {
        return isStreamActiveNative()
    }

    private external fun setupAudioStreamNative()
    private external fun startAudioStreamNative()
    private external fun teardownAudioStreamNative()
    private external fun pauseStreamNative()
    private external fun resumeStreamNative()
    private external fun clearBuffersNative()
    private external fun isStreamActiveNative(): Boolean
    external fun writeAudioDataNative(trackData: java.nio.ByteBuffer, size: Int)
    external fun mixMicWithMusicBuffer(
        micBuffer: java.nio.ByteBuffer,
        musicVolume: Float,
        micVolume: Float,
        bytesRead: Int
    ): Boolean

}