package `in`.reconv.oboemusicplayer

import android.content.Context
import java.nio.ByteBuffer

class NativeKaraokeEngine(private val context: Context) {
    companion object {
        const val DEVICE_UNSPECIFIED = -1
        init {
            System.loadLibrary("OboeMusicPlayerAndRecorder")

        }
    }

    init {
        createKaraokeEngine()
    }

    /**
     * Load background music from a file path
     * @param filePath Full path to the WAV file (e.g., "/storage/emulated/0/Music/background.wav")
     * @return true if loaded successfully, false otherwise
     */
    fun loadBackgroundMusic(filePath: String): Boolean {
        return native_loadBackgroundMusic(filePath)
    }

    fun startKaraokeRecording(
        filePath: String,
        sampleRate: Int = 48000,
        channelCount: Int = 2,
        startPositionMs: Long = 0,
        inputDeviceId: Int = DEVICE_UNSPECIFIED,
        outputDeviceId: Int = DEVICE_UNSPECIFIED,
        performanceMode: PerformanceMode = PerformanceMode.LOW_LATENCY,
        usage: UsageType = UsageType.VOICE_COMMUNICATION,
        inputPreset: InputPresetType = InputPresetType.VOICE_RECOGNITION,
        contentType: ContentTypeEnum = ContentTypeEnum.MUSIC
    ): Boolean {
        return native_startKaraokeRecordingFromPosition(
            filePath, sampleRate, channelCount, startPositionMs,
            inputDeviceId, outputDeviceId,
            performanceMode.oboeValue, usage.oboeValue,
            inputPreset.oboeValue, contentType.oboeValue
        )
    }

    /**
     * Start karaoke recording from a specific position in the music.
     * Convenience alias for startKaraokeRecording with startPositionMs.
     *
     * @param filePath Path where vocal recording will be saved
     * @param sampleRate Sample rate (default 48000)
     * @param channelCount Channel count (default 2)
     * @param startPositionMs Position in milliseconds where music should start
     * @param inputDeviceId Input device ID (default DEVICE_UNSPECIFIED)
     * @param outputDeviceId Output device ID (default DEVICE_UNSPECIFIED)
     * @param performanceMode Performance mode (default LOW_LATENCY)
     * @param usage Usage type (default VOICE_COMMUNICATION)
     * @param inputPreset Input preset (default VOICE_RECOGNITION)
     * @param contentType Content type (default MUSIC)
     * @return true if recording started successfully, false otherwise
     */
    fun startKaraokeRecordingFromPosition(
        filePath: String,
        sampleRate: Int = 48000,
        channelCount: Int = 2,
        startPositionMs: Long,
        inputDeviceId: Int = DEVICE_UNSPECIFIED,
        outputDeviceId: Int = DEVICE_UNSPECIFIED,
        performanceMode: PerformanceMode = PerformanceMode.LOW_LATENCY,
        usage: UsageType = UsageType.VOICE_COMMUNICATION,
        inputPreset: InputPresetType = InputPresetType.VOICE_RECOGNITION,
        contentType: ContentTypeEnum = ContentTypeEnum.MUSIC
    ): Boolean {
        return startKaraokeRecording(
            filePath, sampleRate, channelCount, startPositionMs,
            inputDeviceId, outputDeviceId,
            performanceMode, usage, inputPreset, contentType
        )
    }

    /**
     * Same as [startKaraokeRecording] but the recording buffer is only written to after
     * [leadOffTimeMs] milliseconds have elapsed.  Music playback (and earback, if enabled)
     * start immediately so the singer hears the full intro; the vocal WAV file will only
     * contain audio captured after the lead-off period.
     *
     * @param filePath Path where vocal recording will be saved
     * @param sampleRate Sample rate (default 48000)
     * @param channelCount Channel count (default 2)
     * @param startPositionMs Position in milliseconds where music should start (default 0)
     * @param leadOffTimeMs Milliseconds of audio to discard before writing to the recording file (default 0)
     * @param inputDeviceId Input device ID (default DEVICE_UNSPECIFIED)
     * @param outputDeviceId Output device ID (default DEVICE_UNSPECIFIED)
     * @param performanceMode Performance mode (default LOW_LATENCY)
     * @param usage Usage type (default VOICE_COMMUNICATION)
     * @param inputPreset Input preset (default VOICE_RECOGNITION)
     * @param contentType Content type (default MUSIC)
     * @return true if recording started successfully, false otherwise
     */
    fun startKaraokeRecordingWithLeadOff(
        filePath: String,
        sampleRate: Int = 48000,
        channelCount: Int = 2,
        startPositionMs: Long = 0,
        leadOffTimeMs: Long = 0,
        inputDeviceId: Int = DEVICE_UNSPECIFIED,
        outputDeviceId: Int = DEVICE_UNSPECIFIED,
        performanceMode: PerformanceMode = PerformanceMode.LOW_LATENCY,
        usage: UsageType = UsageType.VOICE_COMMUNICATION,
        inputPreset: InputPresetType = InputPresetType.VOICE_RECOGNITION,
        contentType: ContentTypeEnum = ContentTypeEnum.MUSIC
    ): Boolean {
        return native_startKaraokeRecordingWithLeadOff(
            filePath, sampleRate, channelCount, startPositionMs, leadOffTimeMs,
            inputDeviceId, outputDeviceId,
            performanceMode.oboeValue, usage.oboeValue,
            inputPreset.oboeValue, contentType.oboeValue
        )
    }

    fun stopKaraokeRecording() {
        native_stopKaraokeRecording()
    }

    /**
     * Stop only the recording stream while keeping playback/music active
     * Useful when you want to stop recording vocals but continue listening to the music
     */
    fun stopRecordingOnly() {
        native_stopRecordingOnly()
    }

    fun pauseKaraokeRecording() {
        native_pauseKaraokeRecording()
    }

    fun resumeKaraokeRecording() {
        native_resumeKaraokeRecording()
    }

    // Pause both streams together, resume separately
    fun pauseKaraoke() {
        native_pauseKaraoke()
    }

    fun resumeKaraokeMusic() {
        native_resumeKaraokeMusic()
    }

    fun resumeKaraokeRecordingStream() {
        native_resumeKaraokeRecordingStream()
    }

    // Separate control for recording and playback streams
    fun pauseRecordingStream() {
        native_pauseRecordingStream()
    }

    fun resumeRecordingStream() {
        native_resumeRecordingStream()
    }

    fun pausePlaybackStream() {
        native_pausePlaybackStream()
    }

    fun resumePlaybackStream(): Boolean {
        return native_resumePlaybackStream()
    }

    fun isRecordingStreamActive(): Boolean {
        return native_isRecordingStreamActive()
    }

    fun isPlaybackStreamActive(): Boolean {
        return native_isPlaybackStreamActive()
    }

    fun isRecording(): Boolean {
        return native_isRecording()
    }

    fun getRecordedFrames(): Int {
        return native_getRecordedFrames()
    }

    fun getSampleRate(): Int {
        return native_getSampleRate()
    }

    fun stopPlayback() {
        native_stopPlayback()
    }

    fun isPlaying(): Boolean {
        return native_isPlaying()
    }

    fun clearData() {
        native_clearData()
    }

    fun clearAll() {
        native_clearAll()
    }

    fun saveVocalTrack(filePath: String): Boolean {
        return native_saveVocalTrack(filePath)
    }

    fun saveMusicTrack(filePath: String): Boolean {
        return native_saveMusicTrack(filePath)
    }

    fun saveMixedTrack(filePath: String, vocalVolume: Float = 1.5f, musicVolume: Float = 0.7f): Boolean {
        return native_saveMixedTrack(filePath, vocalVolume, musicVolume)
    }

    fun setLatencyOffset(offsetMs: Int) {
        native_setLatencyOffset(offsetMs)
    }

    fun getLatencyOffset(): Int {
        return native_getLatencyOffset()
    }
    fun getMeasuredLatencyOffset(): Int {
        return native_getMeasuredLatencyOffset()
    }
    // Input stream configuration methods
    fun setInputPerformanceMode(mode: PerformanceMode) {
        native_setInputPerformanceMode(mode.oboeValue)
    }

    fun setInputContentType(type: ContentTypeEnum) {
        native_setInputContentType(type.oboeValue)
    }

    fun setInputUsage(usage: UsageType) {
        native_setInputUsage(usage.oboeValue)
    }

    fun setInputPreset(preset: InputPresetType) {
        native_setInputPreset(preset.oboeValue)
    }

    fun setInputSampleRateConversionQuality(quality: SampleRateConversionQuality) {
        native_setInputSampleRateConversionQuality(quality.oboeValue)
    }

    // Output stream configuration methods
    fun setOutputPerformanceMode(mode: PerformanceMode) {
        native_setOutputPerformanceMode(mode.oboeValue)
    }

    fun setOutputContentType(type: ContentTypeEnum) {
        native_setOutputContentType(type.oboeValue)
    }

    fun setOutputUsage(usage: UsageType) {
        native_setOutputUsage(usage.oboeValue)
    }

    fun setOutputSampleRateConversionQuality(quality: SampleRateConversionQuality) {
        native_setOutputSampleRateConversionQuality(quality.oboeValue)
    }

    // Pitch control methods
    /**
     * Set pitch multiplier for playback
     * @param pitchMultiplier Pitch multiplier (1.0 = normal, 2.0 = one octave up, 0.5 = one octave down)
     */
    fun setPitch(pitchMultiplier: Float) {
        native_setPitch(pitchMultiplier)
    }

    /**
     * Get current pitch multiplier
     * @return Current pitch multiplier (1.0 = normal pitch)
     */
    fun getPitch(): Float {
        return native_getPitch()
    }

    /**
     * Reset pitch shifter to default state (1.0 pitch)
     */
    fun resetPitchShifter() {
        native_resetPitchShifter()
    }

    /**
     * Apply pitch shifting to a WAV file and save to a new file
     * @param inputFilePath Path to input WAV file
     * @param outputFilePath Path to output WAV file with pitch applied
     */
    fun addPitchToWavFile(inputFilePath: String, outputFilePath: String) {
        native_addPitchToWavFile(inputFilePath, outputFilePath)
    }

    // Music volume control during recording phase
    /**
     * Set the volume of background music playback during recording
     * @param volume Volume level (0.0 = silent, 1.0 = normal, 2.0 = max)
     */
    fun setMusicVolume(volume: Float) {
        native_setMusicVolume(volume)
    }

    /**
     * Get current music volume during recording
     * @return Current music volume (0.0 to 2.0)
     */
    fun getMusicVolume(): Float {
        return native_getMusicVolume()
    }

    // Vocal monitoring (earback) controls
    /**
     * Enable or disable real-time vocal monitoring (earback)
     * When enabled, you can hear your own voice while recording
     * @param enabled true to enable earback, false to disable
     */
    fun setVocalEarbackEnabled(enabled: Boolean) {
        native_setVocalMonitoringEnabled(enabled)
    }

    /**
     * Check if vocal monitoring is currently enabled
     * @return true if earback is enabled, false otherwise
     */
    fun isVocalEarbackEnabled(): Boolean {
        return native_isVocalMonitoringEnabled()
    }

    /**
     * Set the volume of vocal monitoring (your own voice)
     * @param volume Volume level (0.0 = silent, 1.0 = normal, 2.0 = max)
     */
    fun setVocalEarbackVolume(volume: Float) {
        native_setVocalMonitoringVolume(volume)
    }

    /**
     * Get current vocal monitoring volume
     * @return Current vocal monitoring volume (0.0 to 2.0)
     */
    fun getVocalEarbackVolume(): Float {
        return native_getVocalMonitoringVolume()
    }

    // Seek and position control
    /**
     * Seek to a specific position in milliseconds during recording
     * @param positionMs Position in milliseconds
     */
    fun seekTo(positionMs: Long) {
        native_seekTo(positionMs)
    }

    /**
     * Get current playback position in milliseconds (during recording)
     * @return Current position in milliseconds
     */
    fun getCurrentPosition(): Long {
        return native_getCurrentPosition()
    }

    /**
     * Get total duration of background music in milliseconds
     * @return Duration in milliseconds
     */
    fun getDuration(): Long {
        return native_getDuration()
    }

    // Music-only playback methods (no recording)
    /**
     * Start playing background music without recording vocals
     * Useful for previewing music or practicing vocals
     * @return true if playback started successfully, false otherwise
     */
    fun startMusicPlayback(): Boolean {
        return native_startMusicPlayback()
    }

    /**
     * Stop music-only playback
     */
    fun stopMusicPlayback() {
        native_stopMusicPlayback()
    }

    /**
     * Check if music-only playback is active
     * @return true if music is playing, false otherwise
     */
    fun isMusicPlaying(): Boolean {
        return native_isMusicPlaying()
    }

    /**
     * Seek to a specific position during music-only playback
     * @param positionMs Position in milliseconds
     */
    fun seekMusicPlayback(positionMs: Long) {
        native_seekMusicPlayback(positionMs)
    }

    /**
     * Get current position during music-only playback
     * @return Current position in milliseconds
     */
    fun getMusicPlaybackPosition(): Long {
        return native_getMusicPlaybackPosition()
    }

    /**
     * Start music playback with earback (full-duplex: mic + speaker, no file recording).
     *
     * Use this when you are recording video with an external library and only need:
     *  - Background music played through the speaker/earphones
     *  - Real-time earback (singer hears their own voice while singing)
     *
     * Earback is controlled with [setVocalMonitoringEnabled] / [setVocalMonitoringVolume]
     * exactly as in karaoke recording mode.
     * No vocal data is written to any file.
     *
     * @param startPositionMs  Music start position in milliseconds (default 0)
     * @param inputDeviceId    Microphone device id, or -1 for default
     * @param outputDeviceId   Speaker/earphone device id, or -1 for default
     * @return true if started successfully
     */
    fun startMusicPlaybackWithEarback(
        startPositionMs: Long = 0L,
        inputDeviceId: Int = -1,
        outputDeviceId: Int = -1
    ): Boolean {
        return native_startMusicPlaybackWithEarback(startPositionMs, inputDeviceId, outputDeviceId)
    }

    /**
     * Stop music playback that was started with [startMusicPlaybackWithEarback].
     */
    fun stopMusicPlaybackWithEarback() {
        native_stopMusicPlaybackWithEarback()
    }

    // ── Standalone Earback ────────────────────────────────────────────────
    // Call initEarback() only when you actually need the singer to hear
    // themselves. It opens its own mic+output stream pair — completely
    // independent of music playback — so latency is always minimal (~5-10 ms)
    // and music playback timing is unaffected.
    //
    // Typical flow for external-video recording with earback:
    //   engine.startMusicPlaybackWithEarback(startMs)   // music only
    //   engine.initEarback()                            // earback when needed
    //   ...
    //   engine.stopEarback()
    //   engine.stopMusicPlaybackWithEarback()

    /**
     * Open a dedicated mic→speaker loopback for real-time earback.
     * No music is mixed in, nothing is recorded to a file.
     * Volume is set via [setVocalMonitoringVolume].
     *
     * @param inputDeviceId  Mic device id, or -1 for default
     * @param outputDeviceId Speaker/earphone device id, or -1 for default
     * @return true if earback streams started successfully
     */
    fun initEarback(inputDeviceId: Int = -1, outputDeviceId: Int = -1): Boolean {
        return native_initEarback(inputDeviceId, outputDeviceId)
    }

    /**
     * Stop and release the earback streams opened by [initEarback].
     */
    fun stopEarback() {
        native_stopEarback()
    }

    /**
     * Returns true while earback streams opened by [initEarback] are running.
     */
    fun isEarbackActive(): Boolean {
        return native_isEarbackActive()
    }

    // ── External-Audio Earback ────────────────────────────────────────────
    // Use these when video is recorded by an external SDK (e.g. Zego) that
    // already owns the microphone.
    //
    // Problem with initEarback() + Zego on some devices (Samsung A35 5G):
    //   - Zego grabs the mic for video recording.
    //   - initEarback() also tries to open an Oboe input stream on the same mic.
    //   - Two concurrent mic captures → robotic voice OR blank recording.
    //
    // Solution:
    //   1. Call initEarbackExternalAudio() instead of initEarback().
    //      → Opens ONLY an Oboe output stream (no mic stream at all).
    //   2. In your Zego onCapturedAudioData callback, call pushEarbackAudio()
    //      with the raw PCM Zego hands you.
    //      → Oboe receives the audio and plays it to the earphones in real time.
    //   3. When done, call stopEarback() as usual.
    //
    // Typical call sequence:
    //   engine.startMusicPlayback()
    //   engine.initEarbackExternalAudio(sampleRate = 48000, channelCount = 1)
    //   // inside Zego audio callback:
    //   engine.pushEarbackAudio(floatPcm, numFrames, channelCount, sampleRate)
    //   ...
    //   engine.stopEarback()
    //   engine.stopMusicPlayback()

    /**
     * Open an Oboe OUTPUT-only earback stream.  No mic input stream is created —
     * feed audio via [pushEarbackAudio].  Stop with [stopEarback].
     *
     * @param outputDeviceId  Speaker/earphone device id, or -1 for default.
     * @param sampleRate      Sample rate of the audio you will push (must match Zego's output).
     * @param channelCount    Channel count of the audio you will push (1 = mono, 2 = stereo).
     * @return true if the output stream started successfully.
     */
    fun initEarbackExternalAudio(
        outputDeviceId: Int = -1,
        sampleRate: Int = 48000,
        channelCount: Int = 1
    ): Boolean {
        return native_initEarbackExternalAudio(outputDeviceId, sampleRate, channelCount)
    }

    /**
     * Push interleaved float PCM audio (from Zego or any external recorder) into
     * the earback ring buffer so Oboe can play it back through the earphones.
     *
     * Call this from your Zego `onCapturedAudioData` callback (or equivalent).
     * It is thread-safe and lock-free — safe to call from an audio thread.
     *
     * @param pcmData      Interleaved float PCM, range [-1.0, 1.0].
     *                     Must have at least [numFrames] × [channelCount] elements.
     * @param numFrames    Number of frames (samples per channel) in [pcmData].
     * @param channelCount Number of channels (should match the value passed to
     *                     [initEarbackExternalAudio]).
     * @param sampleRate   Sample rate of [pcmData] (informational; no resampling
     *                     is performed, so it must match [initEarbackExternalAudio]).
     */
    fun pushEarbackAudio(
        pcmData: FloatArray,
        numFrames: Int,
        channelCount: Int,
        sampleRate: Int
    ) {
        native_pushEarbackAudio(pcmData, numFrames, channelCount, sampleRate)
    }

    fun pushEarbackAudioBuffer(
        buffer: ByteBuffer?, dataLength: Int,
        channelCount: Int, sampleRate: Int
    ) {
        native_pushEarbackAudioBuffer(buffer!!, dataLength, channelCount, sampleRate)
    }
    fun release() {
        deleteKaraokeEngine()
    }

    private fun createKaraokeEngine() {
        native_createKaraokeEngine()
    }

    private fun deleteKaraokeEngine() {
        native_deleteKaraokeEngine()
    }

    // Native methods
    private external fun native_createKaraokeEngine()
    private external fun native_deleteKaraokeEngine()
    private external fun native_loadBackgroundMusic(filePath: String): Boolean
    private external fun native_startKaraokeRecordingFromPosition(
        filePath: String,
        sampleRate: Int,
        channelCount: Int,
        startPositionMs: Long,
        inputDeviceId: Int,
        outputDeviceId: Int,
        performanceMode: Int,
        usage: Int,
        inputPreset: Int,
        contentType: Int
    ): Boolean
    private external fun native_startKaraokeRecordingWithLeadOff(
        filePath: String,
        sampleRate: Int,
        channelCount: Int,
        startPositionMs: Long,
        leadOffTimeMs: Long,
        inputDeviceId: Int,
        outputDeviceId: Int,
        performanceMode: Int,
        usage: Int,
        inputPreset: Int,
        contentType: Int
    ): Boolean
    private external fun native_stopKaraokeRecording()
    private external fun native_stopRecordingOnly()
    private external fun native_pauseKaraokeRecording()
    private external fun native_resumeKaraokeRecording()
    private external fun native_pauseKaraoke()
    private external fun native_resumeKaraokeMusic()
    private external fun native_resumeKaraokeRecordingStream()
    private external fun native_pauseRecordingStream()
    private external fun native_resumeRecordingStream()
    private external fun native_pausePlaybackStream()
    private external fun native_resumePlaybackStream(): Boolean
    private external fun native_isRecordingStreamActive(): Boolean
    private external fun native_isPlaybackStreamActive(): Boolean
    private external fun native_isRecording(): Boolean
    private external fun native_getRecordedFrames(): Int
    private external fun native_getSampleRate(): Int
    private external fun native_stopPlayback()
    private external fun native_isPlaying(): Boolean
    private external fun native_clearData()
    private external fun native_clearAll()
    private external fun native_saveVocalTrack(filePath: String): Boolean
    private external fun native_saveMusicTrack(filePath: String): Boolean
    private external fun native_saveMixedTrack(filePath: String, vocalVolume: Float, musicVolume: Float): Boolean
    private external fun native_setLatencyOffset(offsetMs: Int)
    private external fun native_getLatencyOffset(): Int
    private external fun native_getMeasuredLatencyOffset(): Int
    private external fun native_setInputPerformanceMode(mode: Int)
    private external fun native_setInputContentType(type: Int)
    private external fun native_setInputUsage(usage: Int)
    private external fun native_setInputPreset(preset: Int)
    private external fun native_setInputSampleRateConversionQuality(quality: Int)
    private external fun native_setOutputPerformanceMode(mode: Int)
    private external fun native_setOutputContentType(type: Int)
    private external fun native_setOutputUsage(usage: Int)
    private external fun native_setOutputSampleRateConversionQuality(quality: Int)
    private external fun native_setPitch(pitchMultiplier: Float)
    private external fun native_getPitch(): Float
    private external fun native_resetPitchShifter()
    private external fun native_addPitchToWavFile(inputFilePath: String, outputFilePath: String)
    private external fun native_setMusicVolume(volume: Float)
    private external fun native_getMusicVolume(): Float
    private external fun native_setVocalMonitoringEnabled(enabled: Boolean)
    private external fun native_isVocalMonitoringEnabled(): Boolean
    private external fun native_setVocalMonitoringVolume(volume: Float)
    private external fun native_getVocalMonitoringVolume(): Float
    private external fun native_seekTo(positionMs: Long)
    private external fun native_getCurrentPosition(): Long
    private external fun native_getDuration(): Long
    private external fun native_startMusicPlayback(): Boolean
    private external fun native_stopMusicPlayback()
    private external fun native_isMusicPlaying(): Boolean
    private external fun native_seekMusicPlayback(positionMs: Long)
    private external fun native_getMusicPlaybackPosition(): Long
    private external fun native_startMusicPlaybackWithEarback(startPositionMs: Long, inputDeviceId: Int, outputDeviceId: Int): Boolean
    private external fun native_stopMusicPlaybackWithEarback()
    private external fun native_initEarback(inputDeviceId: Int, outputDeviceId: Int): Boolean
    private external fun native_stopEarback()
    private external fun native_isEarbackActive(): Boolean
    private external fun native_initEarbackExternalAudio(outputDeviceId: Int, sampleRate: Int, channelCount: Int): Boolean
    private external fun native_pushEarbackAudio(pcmData: FloatArray, numFrames: Int, channelCount: Int, sampleRate: Int)
    private external fun native_pushEarbackAudioBuffer(buffer: ByteBuffer, dataLength: Int, channelCount: Int, sampleRate: Int)

}