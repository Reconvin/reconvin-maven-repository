package `in`.reconv.oboemusicplayer

/**
 * Native ROXY DRM file decryptor.
 *
 * Decrypts .roxy encrypted audio files to plaintext (e.g. .mp3).
 * Uses AES-256-CTR with HKDF-SHA256 key derivation.
 */
class NativeCryptoDecryptor {
    companion object {
        init {
            System.loadLibrary("OboeMusicPlayerAndRecorder")
        }
    }

    /**
     * Decrypt a .roxy file to a plaintext output file.
     * @param inputPath  Absolute path to the encrypted .roxy file
     * @param outputPath Absolute path to write the decrypted output (e.g. .mp3)
     * @return true on success, false on failure
     */
    fun decryptRoxyFile(inputPath: String, outputPath: String): Boolean {
        return native_decryptRoxyFile(inputPath, outputPath)
    }

    private external fun native_decryptRoxyFile(inputPath: String, outputPath: String): Boolean
}
