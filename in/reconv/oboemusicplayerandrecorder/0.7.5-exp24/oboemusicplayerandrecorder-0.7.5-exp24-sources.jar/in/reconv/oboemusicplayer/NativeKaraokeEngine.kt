package `in`.reconv.oboemusicplayer

import android.content.Context

class NativeKaraokeEngine(private val context: Context) {
    companion object {
        const val DEVICE_UNSPECIFIED = -1
        init {
            System.loadLibrary("OboeMusicPlayerAndRecorder")

        }
    }

    init {
        createKaraokeEngine()
    }

    /**
     * Load background music from a file path
     * @param filePath Full path to the WAV file (e.g., "/storage/emulated/0/Music/background.wav")
     * @return true if loaded successfully, false otherwise
     */
    fun loadBackgroundMusic(filePath: String): Boolean {
        return native_loadBackgroundMusic(filePath)
    }

    fun startKaraokeRecording(
        filePath: String,
        sampleRate: Int = 48000,
        channelCount: Int = 2,
        inputDeviceId: Int = DEVICE_UNSPECIFIED,
        outputDeviceId: Int = DEVICE_UNSPECIFIED,
        performanceMode: PerformanceMode = PerformanceMode.LOW_LATENCY,
        usage: UsageType = UsageType.MEDIA,
        inputPreset: InputPresetType = InputPresetType.VOICE_RECOGNITION,
        contentType: ContentTypeEnum = ContentTypeEnum.MUSIC
    ): Boolean {
        return native_startKaraokeRecording(
            filePath, sampleRate, channelCount, inputDeviceId, outputDeviceId,
            performanceMode.oboeValue, usage.oboeValue,
            inputPreset.oboeValue, contentType.oboeValue
        )
    }

    fun stopKaraokeRecording() {
        native_stopKaraokeRecording()
    }

    fun pauseKaraokeRecording() {
        native_pauseKaraokeRecording()
    }

    fun resumeKaraokeRecording() {
        native_resumeKaraokeRecording()
    }

    // Separate control for recording and playback streams
    fun pauseRecordingStream() {
        native_pauseRecordingStream()
    }

    fun resumeRecordingStream() {
        native_resumeRecordingStream()
    }

    fun pausePlaybackStream() {
        native_pausePlaybackStream()
    }

    fun resumePlaybackStream() {
        native_resumePlaybackStream()
    }

    fun isRecordingStreamActive(): Boolean {
        return native_isRecordingStreamActive()
    }

    fun isPlaybackStreamActive(): Boolean {
        return native_isPlaybackStreamActive()
    }

    fun isRecording(): Boolean {
        return native_isRecording()
    }

    fun getRecordedFrames(): Int {
        return native_getRecordedFrames()
    }

    fun getSampleRate(): Int {
        return native_getSampleRate()
    }

    fun playMixedTrack(vocalVolume: Float = 1.5f, musicVolume: Float = 0.5f): Boolean {
        return native_playMixedTrack(vocalVolume, musicVolume)
    }

    fun playVocalTrack(volume: Float = 1.5f): Boolean {
        return native_playVocalTrack(volume)
    }

    fun playMusicTrack(volume: Float = 1.0f): Boolean {
        return native_playMusicTrack(volume)
    }

    fun stopPlayback() {
        native_stopPlayback()
    }

    fun isPlaying(): Boolean {
        return native_isPlaying()
    }

    fun clearData() {
        native_clearData()
    }

    fun clearAll() {
        native_clearAll()
    }

    fun saveVocalTrack(filePath: String): Boolean {
        return native_saveVocalTrack(filePath)
    }

    fun saveMusicTrack(filePath: String): Boolean {
        return native_saveMusicTrack(filePath)
    }

    fun saveMixedTrack(filePath: String, vocalVolume: Float = 1.5f, musicVolume: Float = 0.7f): Boolean {
        return native_saveMixedTrack(filePath, vocalVolume, musicVolume)
    }

    fun setLatencyOffset(offsetMs: Int) {
        native_setLatencyOffset(offsetMs)
    }

    fun getLatencyOffset(): Int {
        return native_getLatencyOffset()
    }

    fun setPlaybackVocalVolume(volume: Float) {
        native_setPlaybackVocalVolume(volume)
    }

    fun setPlaybackMusicVolume(volume: Float) {
        native_setPlaybackMusicVolume(volume)
    }

    fun setPlaybackLatencyOffset(offsetMs: Int) {
        native_setPlaybackLatencyOffset(offsetMs)
    }

    // Input stream configuration methods
    fun setInputPerformanceMode(mode: PerformanceMode) {
        native_setInputPerformanceMode(mode.oboeValue)
    }

    fun setInputContentType(type: ContentTypeEnum) {
        native_setInputContentType(type.oboeValue)
    }

    fun setInputUsage(usage: UsageType) {
        native_setInputUsage(usage.oboeValue)
    }

    fun setInputPreset(preset: InputPresetType) {
        native_setInputPreset(preset.oboeValue)
    }

    fun setInputSampleRateConversionQuality(quality: SampleRateConversionQuality) {
        native_setInputSampleRateConversionQuality(quality.oboeValue)
    }

    // Output stream configuration methods
    fun setOutputPerformanceMode(mode: PerformanceMode) {
        native_setOutputPerformanceMode(mode.oboeValue)
    }

    fun setOutputContentType(type: ContentTypeEnum) {
        native_setOutputContentType(type.oboeValue)
    }

    fun setOutputUsage(usage: UsageType) {
        native_setOutputUsage(usage.oboeValue)
    }

    fun setOutputSampleRateConversionQuality(quality: SampleRateConversionQuality) {
        native_setOutputSampleRateConversionQuality(quality.oboeValue)
    }

    // Pitch control methods
    /**
     * Set pitch multiplier for playback
     * @param pitchMultiplier Pitch multiplier (1.0 = normal, 2.0 = one octave up, 0.5 = one octave down)
     */
    fun setPitch(pitchMultiplier: Float) {
        native_setPitch(pitchMultiplier)
    }

    /**
     * Get current pitch multiplier
     * @return Current pitch multiplier (1.0 = normal pitch)
     */
    fun getPitch(): Float {
        return native_getPitch()
    }

    /**
     * Reset pitch shifter to default state (1.0 pitch)
     */
    fun resetPitchShifter() {
        native_resetPitchShifter()
    }

    /**
     * Apply pitch shifting to a WAV file and save to a new file
     * @param inputFilePath Path to input WAV file
     * @param outputFilePath Path to output WAV file with pitch applied
     */
    fun addPitchToWavFile(inputFilePath: String, outputFilePath: String) {
        native_addPitchToWavFile(inputFilePath, outputFilePath)
    }

    // Playback position control methods (for recording phase - music playback)
    /**
     * Seek to a specific position in milliseconds during recording
     * @param positionMs Position in milliseconds
     */
    fun seekTo(positionMs: Long) {
        native_seekTo(positionMs)
    }

    /**
     * Get current playback position in milliseconds (during recording)
     * @return Current position in milliseconds
     */
    fun getCurrentPosition(): Long {
        return native_getCurrentPosition()
    }

    /**
     * Get total duration of background music in milliseconds
     * @return Duration in milliseconds
     */
    fun getDuration(): Long {
        return native_getDuration()
    }

    // Dual-track playback position control methods
    /**
     * Seek to a specific position in milliseconds during dual-track playback
     * @param positionMs Position in milliseconds
     */
    fun seekDualTrackPlayback(positionMs: Long) {
        native_seekDualTrackPlayback(positionMs)
    }

    /**
     * Get current position in milliseconds during dual-track playback
     * @return Current position in milliseconds
     */
    fun getDualTrackCurrentPosition(): Long {
        return native_getDualTrackCurrentPosition()
    }

    /**
     * Get total duration of dual-track playback in milliseconds
     * @return Duration in milliseconds
     */
    fun getDualTrackDuration(): Long {
        return native_getDualTrackDuration()
    }

    fun release() {
        deleteKaraokeEngine()
    }

    private fun createKaraokeEngine() {
        native_createKaraokeEngine()
    }

    private fun deleteKaraokeEngine() {
        native_deleteKaraokeEngine()
    }

    // Native methods
    private external fun native_createKaraokeEngine()
    private external fun native_deleteKaraokeEngine()
    private external fun native_loadBackgroundMusic(filePath: String): Boolean
    private external fun native_startKaraokeRecording(
        filePath: String,
        sampleRate: Int,
        channelCount: Int,
        inputDeviceId: Int,
        outputDeviceId: Int,
        performanceMode: Int,
        usage: Int,
        inputPreset: Int,
        contentType: Int
    ): Boolean
    private external fun native_stopKaraokeRecording()
    private external fun native_pauseKaraokeRecording()
    private external fun native_resumeKaraokeRecording()
    private external fun native_pauseRecordingStream()
    private external fun native_resumeRecordingStream()
    private external fun native_pausePlaybackStream()
    private external fun native_resumePlaybackStream()
    private external fun native_isRecordingStreamActive(): Boolean
    private external fun native_isPlaybackStreamActive(): Boolean
    private external fun native_isRecording(): Boolean
    private external fun native_getRecordedFrames(): Int
    private external fun native_getSampleRate(): Int
    private external fun native_playMixedTrack(vocalVolume: Float, musicVolume: Float): Boolean
    private external fun native_playVocalTrack(volume: Float): Boolean
    private external fun native_playMusicTrack(volume: Float): Boolean
    private external fun native_stopPlayback()
    private external fun native_isPlaying(): Boolean
    private external fun native_clearData()
    private external fun native_clearAll()
    private external fun native_saveVocalTrack(filePath: String): Boolean
    private external fun native_saveMusicTrack(filePath: String): Boolean
    private external fun native_saveMixedTrack(filePath: String, vocalVolume: Float, musicVolume: Float): Boolean
    private external fun native_setLatencyOffset(offsetMs: Int)
    private external fun native_getLatencyOffset(): Int
    private external fun native_setPlaybackVocalVolume(volume: Float)
    private external fun native_setPlaybackMusicVolume(volume: Float)
    private external fun native_setPlaybackLatencyOffset(offsetMs: Int)
    private external fun native_setInputPerformanceMode(mode: Int)
    private external fun native_setInputContentType(type: Int)
    private external fun native_setInputUsage(usage: Int)
    private external fun native_setInputPreset(preset: Int)
    private external fun native_setInputSampleRateConversionQuality(quality: Int)
    private external fun native_setOutputPerformanceMode(mode: Int)
    private external fun native_setOutputContentType(type: Int)
    private external fun native_setOutputUsage(usage: Int)
    private external fun native_setOutputSampleRateConversionQuality(quality: Int)
    private external fun native_setPitch(pitchMultiplier: Float)
    private external fun native_getPitch(): Float
    private external fun native_resetPitchShifter()
    private external fun native_addPitchToWavFile(inputFilePath: String, outputFilePath: String)
    private external fun native_seekTo(positionMs: Long)
    private external fun native_getCurrentPosition(): Long
    private external fun native_getDuration(): Long
    private external fun native_seekDualTrackPlayback(positionMs: Long)
    private external fun native_getDualTrackCurrentPosition(): Long
    private external fun native_getDualTrackDuration(): Long
}