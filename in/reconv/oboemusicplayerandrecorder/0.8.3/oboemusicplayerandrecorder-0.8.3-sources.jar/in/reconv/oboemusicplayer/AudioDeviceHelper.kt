package `in`.reconv.oboemusicplayer

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

data class AudioDevice(
    val id: Int,
    val name: String,
    val type: String,
    val isInput: Boolean,
    val isOutput: Boolean
)

enum class PerformanceMode(val displayName: String, val oboeValue: Int) {
    LOW_LATENCY("Low Latency (Recommended)", 12),
    POWER_SAVING("Power Saving", 13),
    NONE("None (Default)", 10);
}

enum class UsageType(val displayName: String, val oboeValue: Int) {
    VOICE_COMMUNICATION("Voice Communication (Recommended)", 2),
    MEDIA("Media", 1),
    GAME("Game", 14),
    VOICE_COMMUNICATION_SIGNALLING("Voice Call Signalling", 3);
}

enum class InputPresetType(val displayName: String, val oboeValue: Int) {
    VOICE_RECOGNITION("Voice Recognition (Recommended)", 6),
    GENERIC("Generic", 1),
    CAMCORDER("Camcorder", 5),
    VOICE_COMMUNICATION("Voice Communication", 7),
    UNPROCESSED("Unprocessed (Raw)", 9),
    VOICE_PERFORMANCE("Voice Performance", 10);
}

enum class ContentTypeEnum(val displayName: String, val oboeValue: Int) {
    MUSIC("Music (Recommended)", 2),
    SPEECH("Speech", 1),
    MOVIE("Movie", 3),
    SONIFICATION("Sonification", 4);
}

enum class SampleRateConversionQuality(val displayName: String, val oboeValue: Int) {
    BEST("Best (Default)", 2),
    MEDIUM("Medium", 1),
    FASTEST("Fastest", 0);
}

object AudioDeviceHelper {

    fun getAvailableInputDevices(context: Context): List<AudioDevice> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return listOf(AudioDevice(-1, "Default Input", "Built-in", true, false))
        }

        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)

        return devices.map { device ->
            AudioDevice(
                id = device.id,
                name = getDeviceName(device),
                type = getDeviceTypeName(device.type),
                isInput = true,
                isOutput = false
            )
        }
    }

    fun getAvailableOutputDevices(context: Context): List<AudioDevice> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return listOf(AudioDevice(-1, "Default Output", "Built-in", false, true))
        }

        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)

        return devices.map { device ->
            AudioDevice(
                id = device.id,
                name = getDeviceName(device),
                type = getDeviceTypeName(device.type),
                isInput = false,
                isOutput = true
            )
        }
    }

    private fun getDeviceName(device: AudioDeviceInfo): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            device.productName.toString().ifEmpty { getDeviceTypeName(device.type) }
        } else {
            getDeviceTypeName(device.type)
        }
    }

    private fun getDeviceTypeName(type: Int): String {
        return when (type) {
            AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Built-in Earpiece"
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Built-in Speaker"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired Headset"
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Wired Headphones"
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth Headset"
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth A2DP"
            AudioDeviceInfo.TYPE_USB_DEVICE -> "USB Device"
            AudioDeviceInfo.TYPE_USB_ACCESSORY -> "USB Accessory"
            AudioDeviceInfo.TYPE_USB_HEADSET -> "USB-C Headset"
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Built-in Microphone"
            else -> "Unknown ($type)"
        }
    }

    fun getDefaultDeviceDescription(): String {
        return "Default (Auto)"
    }
}

