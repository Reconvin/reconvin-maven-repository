package `in`.reconv.oboemusicplayer

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.util.Log
import `in`.reconv.oboemusicplayer.NativeInterface.effectDescriptionMap
import `in`.reconv.oboemusicplayer.datatype.Effect
import `in`.reconv.oboemusicplayer.datatype.EffectDescription
import java.io.File
import java.io.FileInputStream
import java.io.IOException

class NativeMusicPlayer {
    /**
     * A native method that is implemented by the 'OboeMusicPlayerAndRecorder' native library,
     * which is packaged with this application.
     */

    external fun onRecordingStarted(eventInfo: String): String

    fun addEffect(effect: Effect) {
        Log.d("INTERFACE", String.format("Effect %s added", effect.name))
        addDefaultEffectNativePreview(
            convertEffectToId(
                effect
            )
        )
    }

    private fun convertEffectToId(effect: Effect): Int =
        effectDescriptionMap[effect.name]?.id ?: -1

    private external fun addDefaultEffectNativePreview(id: Int)

    external fun createPlayer(): Boolean
    external fun createPlayerPreview(): Boolean

    companion object {
        val NUM_PLAY_CHANNELS: Int = 2
        // Used to load the 'oboemusicplayerandrecorder' library on application startup.
        init {
            System.loadLibrary("OboeMusicPlayerAndRecorder")
        }
        val TAG: String = "MusicPlayer"
    }

    fun loadWavFile(filePath: String, index: Int, pan: Float) {
        try {
            // Open the file using FileInputStream
            val file = File(filePath)
            val dataStream = FileInputStream(file)

            // Get the file size
            val dataLen = file.length().toInt()

            // Read the file data into a byte array
            val dataBytes = ByteArray(dataLen)
            dataStream.read(dataBytes, 0, dataLen)

            // Call your native function with the data
            loadWavAssetNative(dataBytes, index, pan)

            // Close the stream
            dataStream.close()
        } catch (ex: IOException) {
            Log.i(TAG, "IOException: $ex")
        } catch (ex: OutOfMemoryError) {
            Log.e(TAG, "OutOfMemoryError loading wav: $ex")
        }
    }

    fun loadWavFilePreview(filePath: String, index: Int, pan: Float) {
        try {
            // Open the file using FileInputStream
            val file = File(filePath)
            val dataStream = FileInputStream(file)

            // Get the file size
            val dataLen = file.length().toInt()

            // Read the file data into a byte array
            val dataBytes = ByteArray(dataLen)
            dataStream.read(dataBytes, 0, dataLen)

            // Call your native function with the data
            loadWavAssetNativePreview(dataBytes, index, pan)

            // Close the stream
            dataStream.close()
        } catch (ex: IOException) {
            Log.i(TAG, "IOException: $ex")
        } catch (ex: OutOfMemoryError) {
            Log.e(TAG, "OutOfMemoryError loading preview: $ex")
        }
    }


    fun setupAudioStream() {
        setupAudioStreamNative(NUM_PLAY_CHANNELS)
    }

    fun setupAudioStreamPreview() {
        setupAudioStreamNativePreview(NUM_PLAY_CHANNELS)
    }

    fun startAudioStream() {
        startAudioStreamNative()
    }

    fun startAudioStreamPreview() {
        startAudioStreamNativePreview()
    }

    fun teardownAudioStream() {
        teardownAudioStreamNative()
    }

    fun teardownAudioStreamPreview() {
        teardownAudioStreamNativePreview()
    }

    fun getDuration(index: Int, mSampleRate: Int, mChannelCount: Int): Long{
        return getDurationNative(index, mSampleRate, mChannelCount)
    }

    fun getDurationPreview(mSampleRate: Int, mChannelCount: Int, index: Int): Long{
        return getDurationNativePreview(mSampleRate, mChannelCount, index)
    }

    fun unloadWavAssets() {
        unloadWavAssetsNative()
    }

    fun unloadWavAssetsPreview() {
        unloadWavAssetsNativePreview()
    }

    // Enables effect at index
    fun enableEffectAt(turnOn: Boolean, index: Int) {
        Log.d("INTERFACE", String.format("Effect %b at index %d", turnOn, index))
        enableEffectNativePreview(index, turnOn)
    }

    // Signals params were updated at index
    fun updateParamsAt(effect: Effect, index: Int) {
        Log.d(
            "INTERFACE",
            String.format(
                "Params were updated at index %d to %f",
                index,
                effect.paramValues[0]
            )
        )
        modifyEffectNativePreview(
            convertEffectToId(
                effect
            ), index, effect.paramValues
        )
    }

    // Removes effect at index
    fun removeEffectAt(index: Int) {
        Log.d("INTERFACE", String.format("Effect was removed at index %d", index))
        removeEffectNativePreview(index)
    }

    // Rotates existing effect from index to another
    fun rotateEffectAt(from: Int, to: Int) {
        Log.d("INTERFACE", String.format("Effect was rotated from %d to %d", from, to))
        rotateEffectNativePreview(from, to)
    }

    fun enable(enable: Boolean) {
        Log.d("INTERFACE", "Enabling effects: $enable")
        enablePassthroughNativePreview(enable)
    }

    // State of audio engine
    external fun createAudioEnginePreview()

    external fun destroyAudioEnginePreview()

    external fun processWavFileNativePreview( inputPath: String, outputPath: String)

    // These functions populate effectDescriptionMap
    private external fun getEffectsPreview(): Array<EffectDescription>
    private external fun removeEffectNativePreview(index: Int)
    private external fun rotateEffectNativePreview(from: Int, to: Int)
    private external fun modifyEffectNativePreview(id: Int, index: Int, params: FloatArray)
    private external fun enableEffectNativePreview(index: Int, enable: Boolean)
    private external fun enablePassthroughNativePreview(enable: Boolean)
    private external fun getDurationNative(index: Int, mSampleRate: Int, mChannelCount: Int): Long
    private external fun getDurationNativePreview(mSampleRate: Int, mChannelCount: Int, index: Int): Long
    private external fun setupAudioStreamNative(numChannels: Int)
    private external fun setupAudioStreamNativePreview(numChannels: Int)
    private external fun startAudioStreamNative()
    private external fun startAudioStreamNativePreview()
    private external fun teardownAudioStreamNative()
    private external fun teardownAudioStreamNativePreview()
    private external fun loadWavAssetNative(wavBytes: ByteArray, index: Int, pan: Float)
    private external fun loadWavAssetNativePreview(wavBytes: ByteArray, index: Int, pan: Float)
    private external fun unloadWavAssetsNative()
    private external fun unloadWavAssetsNativePreview()
    external fun trigger(drumIndex: Int)
    external fun triggerPreview(drumIndex: Int)
    external fun stopTrigger(drumIndex: Int)
    external fun stopTriggerPreview(drumIndex: Int)
    external fun setPan(index: Int, pan: Float)
    external fun setPanPreview(index: Int, pan: Float)
    external fun getPan(index: Int): Float
    external fun getPanPreview(index: Int): Float
    external fun setGain(index: Int, gain: Float)
    external fun setGainPreview(index: Int, gain: Float)
    external fun getGain(index: Int): Float
    external fun getGainPreview(index: Int): Float
    external fun getOutputReset() : Boolean
    external fun getOutputResetPreview() : Boolean
    external fun clearOutputReset()
    external fun clearOutputResetPreview()
    external fun restartStream()
    external fun restartStreamPreview()
    external fun pauseTrigger()
    external fun pauseTriggerPreview()
    external fun resumeTrigger()
    external fun resumeTriggerPreview()
    external fun seekToPosition(position: Long, mSampleRate : Int, mChannelCount: Int)
    external fun seekToPositionPreview(position: Long, mSampleRate : Int, mChannelCount: Int, index: Int)
    external fun getPosition(index: Int, mSampleRate : Int, mChannelCount: Int): Long
    external fun getPositionPreview(index: Int, mSampleRate : Int, mChannelCount: Int): Long
    // External functions for Recording
    external fun create(): Boolean
    external fun isAAudioRecommended(): Boolean
    external fun setAPI(apiType: Int): Boolean
    external fun setEffectOn(isEffectOn: Boolean): Boolean
    external fun setRecordingDeviceId(deviceId: Int)
    external fun setPlaybackDeviceId(deviceId: Int)
    external fun delete()
    external fun native_setDefaultStreamValues(defaultSampleRate: Int, defaultFramesPerBurst: Int)
    external fun startRecording(
        fullPathTofile: String?,
        inputPresetPreference: Int,
        startRecordingTime: Long
    )

    external fun stopRecording()
    external fun resumeRecording()
    external fun pauseRecording()
    external fun getMusicPlayerTimeStamp(): Long
    external fun getMusicPlayerTimeStampPreview(): Long
    external fun getRecorderTimeStamp(): Long
    external fun getMusicPlayerFramePosition(): Long
    external fun getMusicPlayerFramePositionPreview(): Long
    external fun getRecorderFramePosition(): Long
    external fun setCallbackObject(callbackObject: Any?)
    external fun getPlayerAudioSessionId(): Int
    external fun getPlayerAudioSessionIdPreview(): Int
    external fun clearEffects()

    // Pitch control methods
    external fun setPitch(pitchMultiplier: Float)
    external fun getPitch(): Float
    external fun setTempo(tempoChange: Float)
    external fun resetPitchShifter()
    external fun getSampleRate(): Int

    // Save wav file with pitch applied
    external fun addPitchToWavFileNative( inputPath: String, outputPath: String)

    fun setDefaultStreamValues(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            val myAudioMgr = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val sampleRateStr = myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)
            val defaultSampleRate = sampleRateStr.toInt()
            val framesPerBurstStr =
                myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)
            val defaultFramesPerBurst = framesPerBurstStr.toInt()

            native_setDefaultStreamValues(defaultSampleRate, defaultFramesPerBurst)
        }
    }
}