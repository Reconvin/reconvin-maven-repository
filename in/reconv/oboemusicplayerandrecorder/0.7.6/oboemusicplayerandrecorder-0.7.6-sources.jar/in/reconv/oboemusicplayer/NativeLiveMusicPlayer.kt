package `in`.reconv.oboemusicplayer

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.util.Log
import `in`.reconv.oboemusicplayer.datatype.Effect
import java.io.File
import java.io.FileInputStream
import java.io.IOException

class NativeLiveMusicPlayer {
    external fun onRecordingStarted(eventInfo: String): String

    fun addEffect(effect: Effect) {
        Log.d("INTERFACE", String.format("Effect %s added", effect.name))
    }

    private fun convertEffectToId(effect: Effect): Int =
        NativeInterface.effectDescriptionMap[effect.name]?.id ?: -1

    external fun createPlayer(): Boolean

    companion object {
        val NUM_PLAY_CHANNELS: Int = 2
        // Used to load the 'oboemusicplayerandrecorder' library on application startup.
        init {
            System.loadLibrary("OboeMusicPlayerAndRecorder")
        }
        val TAG: String = "MusicPlayer"
    }

    fun loadWavFile(filePath: String, index: Int, pan: Float) {
        try {
            // Open the file using FileInputStream
            val file = File(filePath)
            val dataStream = FileInputStream(file)

            // Get the file size
            val dataLen = file.length().toInt()

            // Read the file data into a byte array
            val dataBytes = ByteArray(dataLen)
            dataStream.read(dataBytes, 0, dataLen)

            // Call your native function with the data
            loadWavAssetNative(dataBytes, index, pan)

            // Close the stream
            dataStream.close()
        } catch (ex: IOException) {
            Log.i(TAG, "IOException: $ex")
        }
    }

    fun loadWavFilePreview(filePath: String, index: Int, pan: Float) {
        try {
            // Open the file using FileInputStream
            val file = File(filePath)
            val dataStream = FileInputStream(file)

            // Get the file size
            val dataLen = file.length().toInt()

            // Read the file data into a byte array
            val dataBytes = ByteArray(dataLen)
            dataStream.read(dataBytes, 0, dataLen)

            // Close the stream
            dataStream.close()
        } catch (ex: IOException) {
            Log.i(TAG, "IOException: $ex")
        }
    }


    fun setupAudioStream() {
        setupAudioStreamNative(NUM_PLAY_CHANNELS)
    }

    fun startAudioStream() {
        startAudioStreamNative()
    }

    fun teardownAudioStream() {
        teardownAudioStreamNative()
    }

    fun getDuration(index: Int, mSampleRate: Int, mChannelCount: Int): Long{
        return getDurationNative(index, mSampleRate, mChannelCount)
    }

    fun unloadWavAssets() {
        unloadWavAssetsNative()
    }

    // Signals params were updated at index
    fun updateParamsAt(effect: Effect, index: Int) {
        Log.d(
            "INTERFACE",
            String.format(
                "Params were updated at index %d to %f",
                index,
                effect.paramValues[0]
            )
        )
    }


    private external fun getDurationNative(index: Int, mSampleRate: Int, mChannelCount: Int): Long

    private external fun setupAudioStreamNative(numChannels: Int)

    private external fun startAudioStreamNative()

    private external fun teardownAudioStreamNative()

    private external fun loadWavAssetNative(wavBytes: ByteArray, index: Int, pan: Float)

    private external fun unloadWavAssetsNative()

    external fun trigger(drumIndex: Int)

    external fun stopTrigger(drumIndex: Int)

    external fun setPan(index: Int, pan: Float)

    external fun getPan(index: Int): Float

    external fun setGain(index: Int, gain: Float)

    external fun getGain(index: Int): Float

    external fun restartStream()

    external fun pauseTrigger()

    external fun resumeTrigger()

    external fun seekToPosition(position: Long, mSampleRate : Int, mChannelCount: Int)

    external fun getPosition(index: Int, mSampleRate : Int, mChannelCount: Int): Long

    // External functions for Recording
    external fun create(): Boolean
    external fun isAAudioRecommended(): Boolean
    external fun setAPI(apiType: Int): Boolean
    external fun setEffectOn(isEffectOn: Boolean): Boolean
    external fun setRecordingDeviceId(deviceId: Int)
    external fun setPlaybackDeviceId(deviceId: Int)
    external fun delete()
    external fun native_setDefaultStreamValues(defaultSampleRate: Int, defaultFramesPerBurst: Int)
    external fun startRecording(
        fullPathTofile: String?,
        inputPresetPreference: Int,
        startRecordingTime: Long
    )

    external fun stopRecording()
    external fun resumeRecording()
    external fun pauseRecording()
    external fun getMusicPlayerTimeStamp(): Long

    external fun getRecorderTimeStamp(): Long
    external fun getMusicPlayerFramePosition(): Long
    external fun getRecorderFramePosition(): Long
    external fun setCallbackObject(callbackObject: Any?)
    external fun getPlayerAudioSessionId(): Int
    external fun mixMicWithMusicBuffer(
        micBuffer: java.nio.ByteBuffer,
        musicVolume: Float,
        micVolume: Float,
        bytesRead: Int
    ): Boolean


    // methods for pitch shifting
    external fun setPitch(pitchMultiplier: Float)
    external fun getPitch(): Float
    external fun resetPitchShifter()
    external fun addPitchToWavFileNative( inputPath: String, outputPath: String)

    fun setDefaultStreamValues(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            val myAudioMgr = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val sampleRateStr = myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)
            val defaultSampleRate = sampleRateStr.toInt()
            val framesPerBurstStr =
                myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)
            val defaultFramesPerBurst = framesPerBurstStr.toInt()

            native_setDefaultStreamValues(defaultSampleRate, defaultFramesPerBurst)
        }
    }
}