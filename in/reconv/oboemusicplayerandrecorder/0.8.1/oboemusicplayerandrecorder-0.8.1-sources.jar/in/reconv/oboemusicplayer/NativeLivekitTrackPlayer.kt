package `in`.reconv.oboemusicplayer

class NativeLivekitTrackPlayer {

    external fun createPlayer(): Boolean

    companion object{
        init {
            System.loadLibrary("OboeMusicPlayerAndRecorder")
        }
    }

    fun setupAudioStream(){
        setupAudioStreamNative()
    }

    fun startAudioStream() {
        startAudioStreamNative()
    }

    fun teardownAudioStream() {
        teardownAudioStreamNative()
    }

    fun clearBuffers() {
        clearBuffersNative()
    }

    private external fun setupAudioStreamNative()
    private external fun startAudioStreamNative()
    private external fun teardownAudioStreamNative()
    private external fun clearBuffersNative()
    external fun writeAudioDataNative(trackData: java.nio.ByteBuffer, size: Int, musicVolume: Float)
    external fun mixMicWithMusicBuffer(
        micBuffer: java.nio.ByteBuffer,
        musicVolume: Float,
        micVolume: Float,
        bytesRead: Int
    ): Boolean

}