package `in`.reconv.oboemusicplayer

import java.nio.ByteBuffer
import java.nio.ByteOrder
import android.util.Log

object ProcessedAudioReceiver {
    // Maybe 4-5 frames worth of audio (480 * 4 = 1920 bytes)
    private val ringBuffer = AudioRingBuffer(7680)  // About 4 frames worth
    private var processedBuffer: ByteBuffer? = null
    private val syncObject = Object()

    @JvmStatic
    fun onProcessedAudioAvailable(buffer: ByteBuffer, numFrames: Int) {
        ringBuffer.write(buffer)
    }

    fun getProcessedBuffer(requestedBytes: Int): ByteBuffer? {
        // Create output buffer if needed
        if (processedBuffer == null || processedBuffer!!.capacity() < requestedBytes) {
            processedBuffer = ByteBuffer.allocateDirect(requestedBytes)
                .order(ByteOrder.nativeOrder())
        }

        // Try to read from ring buffer
        return if (ringBuffer.read(processedBuffer!!, requestedBytes)) {
            processedBuffer
        } else {
            null
        }
    }
}